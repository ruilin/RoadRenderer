#!/usr/bin/python
# -*- coding:UTF-8 -*-

from Tkinter import *
from DataMapper import Mapper
from PIL import Image, ImageDraw

DATA = [
    [115.157989,
     -30.601056],
    [115.158096,
     -30.600876],
    [115.158195,
     -30.60075],
    [115.158264,
     -30.600548],
    [115.158554,
     -30.600325],
    [115.158653,
     -30.600295],
    [115.158775,
     -30.600329],
    [115.158843,
     -30.600411],
    [115.158882,
     -30.60052],
    [115.158874,
     -30.60088]
]

canvasW = 500
canvasH = 500

mapping = Mapper(canvasW, canvasH)
result = mapping.mapping(DATA)

# 画在窗口
window = Tk()
window.title("Road Renderer")
canvas = Canvas(window, width=canvasW, height=canvasH, bg="white")
canvas.create_line(result, width=20, fill="black", tags="line")
canvas.pack()


# 保存图像
points = []
for i in range(len(result)):
    points.append(tuple(result[i]))

im = Image.new("RGB", (canvasW, canvasH), "#ffffff")
dr = ImageDraw.Draw(im)
dr.line(points, fill="black", width=20)
im.save("temp.png")

window.mainloop()

